
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Facturacion;
/**
 *
 * @author Josem
 */
public class Facturacion {
    static Lectura mu = new Lectura();
    static int NumeroLavadas;
    static int Precio = 50000;
    static int preguntar;
    static int totalLavanderia;
    static int tipo;
    static int VIP = 200000;
    static int normalCompleta = 180000;
    static int normal = 140000;
    static int totalHabitacion;
    static int numeroNoches;
    static String numeroHabitacion;
    static String nombreHuesped;
    static int total;
    static int daños;
    
    public static void cobrar(){
        nombreHuesped = mu.leerString("Por favor indique su nombre");
        numeroHabitacion = mu.leerString("Por favor ingrese el numero de habitacion");
        tipo = mu.leerInt("por favor ingrese (1) si su habitación es VIP, (2) si su habitacion es normal todo incluido, (3) si su habitacion es normal");
        numeroNoches = mu.leerInt("ingrese el numero de noches que permanecio");
        if(tipo == 1){
            totalHabitacion = VIP *numeroNoches;
        }
        if(tipo == 2){
            totalHabitacion = normalCompleta * numeroNoches;
        }
        if(tipo == 3){
            totalHabitacion = normal * numeroNoches;
        }
        System.out.println("el precio de su habitacion es de:"+totalHabitacion);
        preguntar = mu.leerInt("Ingrese (1) si lavo (2)si no lavo");
        if(lavar(preguntar)){
            NumeroLavadas = mu.leerInt("Ingrese el numero de veces que lavo");
            totalLavanderia = NumeroLavadas * Precio;
            System.out.println("el precio de su lavada es de "+totalLavanderia);
        }
        else{
            System.out.println("No usaste la lavadora");
        }
        total = totalHabitacion + totalLavanderia;
        System.out.println(nombreHuesped+ "el total a pagar es de:"+total);
    }
    

    public static Boolean lavar(int preguntar){
        if(preguntar == 1){
        return true; 
        }else {
        return false;  
        }
    }
 

    public static void main(String[] args) {
        cobrar ();
    }
}